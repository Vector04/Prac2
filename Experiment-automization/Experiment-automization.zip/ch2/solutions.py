import numpy as np


class ElectronicLoadMearsurements:
    """A class that stores electronic mearurements in the form of (resistance, voltage)."""

    def __init__(self):
        pass

    def add_measurement(self, resistance, voltage):
        """Add a measurement to be stored."""
        try:
            self.measurements = np.append(
                self.measurements, [[resistance, voltage]], axis=0)
        except AttributeError:
            self.measurements = np.array([[resistance, voltage]])

    def get_resistances(self):
        """Returns all the resistances stored."""
        return self.measurements[:,0]

    def get_voltages(self):
        """Returns all the voltages stored."""
        return self.measurements[:,1]

    def get_currents(self):
        """Returns all the currents of every entry."""
        return self.measurements[:,1] / self.measurements[:,0]

    def get_powers(self):
        """Returns all powers of every entry."""
        return self.measurements[:,1]**2 / self.measurements[:,0]

    def delete_measurements(self):
        """Deletes all the measurements stored."""
        self.measurements = None


elm = ElectronicLoadMearsurements()
help(elm)
elm.add_measurement(2, 3)
elm.add_measurement(3, 4)
print(elm.measurements)
print(elm.get_powers())


def average(values):
    # assert isinstance(values, list), "Input needs to be an array-like"
    try:
        return sum(values) / len(values)
    except TypeError:
        print(f"Exception: `{values}'  needs to be an array-like!")
    except ZeroDivisionError:
        print(f"Exception: {values} is empty!")
    return None


print(average("1234"))
